const {
  Engine,
  World,
  Bodies,
  Composite,
} = Matter;

// Create engine
const engine = Engine.create();
const world = engine.world;

// Create canvas and context
const simDiv = document.querySelector(".sim");
const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;
simDiv.appendChild(canvas);

window.onresize = () => {
  canvas.width = simDiv.clientWidth;
  canvas.height = simDiv.clientHeight;
};

// Design parameters
const PEG_RAD = 3;
const GAP = 30;
const ROWS = 16;
const BOTTOM_ROW_PEGS = ROWS + 2;
const BIN_WIDTH = GAP * 0.8;
const BIN_HEIGHT = 30;
const BIN_Y_OFFSET = 40;

// Create pegs
const pegs = [];
for (let r = 0; r < ROWS; r++) {
  const pegsInRow = r + 3;
  for (let c = 0; c < pegsInRow; c++) {
    const x = canvas.width / 2 + (c - (pegsInRow - 1) / 2) * GAP;
    const y = GAP + r * GAP;
    const peg = Bodies.circle(x, y, PEG_RAD, {
      isStatic: true,
      label: "Peg",
    });
    pegs.push(peg);
  }
}
World.add(world, pegs);

// Bin setup
const lastPegY = GAP + (ROWS - 1) * GAP;
const binsY = lastPegY + BIN_Y_OFFSET;
const bins = [];
const binPositions = [];
const middleBinIndex = Math.floor((BOTTOM_ROW_PEGS - 1) / 2);

// Exponential multiplier parameters
const minMultiplier = 0.2;
const maxMultiplier = 100;
const exponent = 3.2;

function getExponentialMultiplier(index) {
  const distance = Math.abs(index - middleBinIndex);
  const maxDist = middleBinIndex;
  const normalized = distance / maxDist;
  return minMultiplier + (maxMultiplier - minMultiplier) * Math.pow(normalized, exponent);
}

// Create bins
for (let i = 0; i < BOTTOM_ROW_PEGS - 1; i++) {
  const x = canvas.width / 2 + ((i + 0.5) - (BOTTOM_ROW_PEGS - 1) / 2) * GAP;
  const y = binsY;

  binPositions.push({ x, y, width: BIN_WIDTH, height: BIN_HEIGHT });

  const bin = Bodies.rectangle(x, y, BIN_WIDTH, BIN_HEIGHT, {
    isStatic: true,
    isSensor: true,
    label: `Bin ${i + 1}`,
  });

  bins.push(bin);
}
World.add(world, bins);

// Despawn zone overlay (center bin)
const despawnZone = binPositions[middleBinIndex];
const DESPAWN_ZONE_X = despawnZone.x;
const DESPAWN_ZONE_WIDTH = BIN_WIDTH;
const DESPAWN_ZONE_Y = despawnZone.y;
const DESPAWN_ZONE_HEIGHT = BIN_HEIGHT;

// Balance and betting
let balance = 1000;
let currentBet = 0;

const balanceDiv = document.querySelector(".balance");
const betInput = document.querySelector(".bet-input");
const dropButton = document.querySelector(".drop-button");
const resetButton = document.querySelector(".reset-button");
const autoButton = document.querySelector(".auto-button");

function updateBalanceDisplay() {
  balanceDiv.textContent = `$${balance.toFixed(2)}`;
}

updateBalanceDisplay();

function dropBall() {
  let bet = parseFloat(betInput.value);
  if (isNaN(bet) || bet <= 0) {
    alert("Enter a valid bet amount.");
    return;
  }

  if (bet > balance) {
    betInput.value = balance.toFixed(2);
    alert("You can't bet more than your balance.");
    return;
  }

  currentBet = bet;
  balance -= bet;
  updateBalanceDisplay();

  const offset = (Math.random() - 0.5) * 5;
  const ball = Bodies.circle(canvas.width / 2 + offset, 10, 6, {
    restitution: 0.7,
    label: "Ball",
    plugin: { betAmount: bet },
  });
  World.add(world, ball);
}

dropButton.addEventListener("click", () => dropBall());

resetButton.addEventListener("click", () => {
  const bodies = Composite.allBodies(world);
  for (const body of bodies) {
    if (body.label === "Ball") {
      Composite.remove(world, body);
    }
  }
  balance = 1000;
  updateBalanceDisplay();
  betInput.value = "";
  autoButton.textContent = "Auto";

  if (autoInterval) {
    clearInterval(autoInterval);
    autoInterval = null;
  }
});

let autoInterval = null;
autoButton.addEventListener("click", () => {
  if (autoInterval) {
    clearInterval(autoInterval);
    autoInterval = null;
    autoButton.textContent = "Auto";
  } else {
    autoInterval = setInterval(() => dropBall(), 500);
    autoButton.textContent = "Stop";
  }
});

// Ground
const ground = Bodies.rectangle(
  canvas.width / 2,
  canvas.height + 50,
  canvas.width * 2,
  60,
  { isStatic: true, label: "Ground" }
);
World.add(world, ground);

// Render loop
function render() {
  Engine.update(engine, 30);
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  const bodies = Composite.allBodies(world);

  for (let body of bodies) {
    if (body.label === "Ball") {
      for (let i = 0; i < binPositions.length; i++) {
        const bin = binPositions[i];
        if (
          body.position.x > bin.x - bin.width / 2 &&
          body.position.x < bin.x + bin.width / 2 &&
          body.position.y > bin.y - bin.height / 2 &&
          body.position.y < bin.y + bin.height / 2
        ) {
          const multiplier = getExponentialMultiplier(i);
          const betAmount = body.plugin?.betAmount || 0;
          const winnings = betAmount * multiplier;
          balance += winnings;
          updateBalanceDisplay();

          console.log(
            `Ball in Bin ${i + 1}: x${multiplier.toFixed(2)} - Winnings: $${winnings.toFixed(2)}`
          );

          Composite.remove(world, body);
          break;
        }
      }
    }

    // Drawing shapes
    const vertices = body.vertices;
    if (body.label === "Peg") {
      ctx.fillStyle = "#ffffff";
    } else if (body.label === "Ball") {
      ctx.fillStyle = "#F7003A";
    } else if (body.label.startsWith("Bin")) {
      const i = parseInt(body.label.split(" ")[1]) - 1;
      const distFromCenter = Math.abs(i - middleBinIndex);
      const maxDist = middleBinIndex;
      const gradientFactor = Math.pow(distFromCenter / maxDist, 1.5);
      const redIntensity = Math.round(gradientFactor * 200);
      ctx.fillStyle = `rgb(255, ${255 - redIntensity}, ${255 - redIntensity})`;
    } else {
      ctx.fillStyle = "#888888";
    }

    ctx.beginPath();
    ctx.moveTo(vertices[0].x, vertices[0].y);
    for (let j = 1; j < vertices.length; j++) {
      ctx.lineTo(vertices[j].x, vertices[j].y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = "#000000";
    ctx.stroke();
  }

  // Draw bin overlays and multipliers (no hit count)
  for (let i = 0; i < binPositions.length; i++) {
    const { x, y, width, height } = binPositions[i];
    const multiplier = getExponentialMultiplier(i);

    ctx.fillStyle = "rgba(255, 255, 255, 0.1)";
    ctx.fillRect(x - width / 2, y - height / 2, width, height);

    ctx.fillStyle = "black";
    ctx.font = "12px Arial";
    ctx.textAlign = "center";
    ctx.fillText(`x${multiplier.toFixed(2)}`, x, y + 5);
  }

  // Despawn zone overlay
  ctx.fillStyle = "rgba(255, 0, 0, 0.2)";
  ctx.fillRect(
    DESPAWN_ZONE_X - DESPAWN_ZONE_WIDTH / 2,
    DESPAWN_ZONE_Y - DESPAWN_ZONE_HEIGHT / 2,
    DESPAWN_ZONE_WIDTH,
    DESPAWN_ZONE_HEIGHT
  );

  requestAnimationFrame(render);
}

requestAnimationFrame(render);
